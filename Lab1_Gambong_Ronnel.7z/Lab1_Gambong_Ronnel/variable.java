package Lab1_Gambong_Ronnel;

public class variable {

    public static void main(String[] args) {
        double gross = 0.0;
        int i = 0x11;
        int o = 067;
        int age = 1;
        boolean f = false;
        char d = 'a';
        String nm = "noname";

        // Gross statement output that I called from the variable
        System.out.println("Gross sale = " + gross);
        // Age value for the statement
        System.out.println("Age = " + age);
        // Final statement output
        System.out.println("Final = " + f);

        // Statement for location which is a literal
        System.out.println("Location = " + i);
        // Old file statement
        System.out.println("Old file = " + o);
        // Display default values
        System.out.println("Default = " + d);
        // Display noname values
        System.out.println("Name = " + nm);
    }
}