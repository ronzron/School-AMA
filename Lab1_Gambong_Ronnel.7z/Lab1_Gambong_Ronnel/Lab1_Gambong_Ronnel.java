package Lab1_Gambong_Ronnel;

public class Lab1_Gambong_Ronnel {
    public static void main(String[] args) {
        System.out.println("\"I am writing a program that will display \"text\" with escape characters.");
        System.out.println("\t At the beginning of this sentence it has tab escape character.");
        System.out.println(
                "\n \nThere are two new line before this sentence and you also ahve to include \'single \n quote\' and \\back slash\\ characters in this sentence.\" ");

    }
}
