package Lab2_Gambong_Ronnel;

public class OddEven {
    public static void main(String[] args) {
        int num = 5;
        if (num % 2 == 0)
            System.out.println("number: " + num);
        else
            System.out.println(num + " is odd number");
    }
}
