package Lab2_Gambong_Ronnel;

public class integervalue {

    public static void main(String[] args) {
        int a = 25;
        int b = 3;

        System.out.println("First Integer: " + a);
        System.out.println("Second Integer: " + b);
        System.out.println("Sum: " + (a + b));
        System.out.println("Difference: " + (a - b));
        System.out.println("Product: " + (a * b));
        System.out.println("Quotient:  " + (a / b));
        System.out.println("Average: " + (a + b) / 2);
        System.out.println("Max Integer: " + Math.max(a, b));
        System.out.println("Min Integer: " + Math.min(a, b));
    }
}